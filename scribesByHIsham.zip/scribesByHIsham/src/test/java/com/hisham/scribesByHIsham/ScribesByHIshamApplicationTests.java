package com.hisham.scribesByHIsham;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScribesByHIshamApplicationTests {

	@Test
	void contextLoads() {
	}

}
